# GRPC Server Example

Used for the [Server](https://eclipse.dev/velocitas/docs/tutorials/grpc_service_generation/create_server/) example.
