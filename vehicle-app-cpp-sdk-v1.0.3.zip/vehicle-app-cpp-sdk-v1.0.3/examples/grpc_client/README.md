# GRPC Client Example

Used for the [Client](https://eclipse.dev/velocitas/docs/tutorials/grpc_service_generation/create_client/) example.
